package com.example.minimarket

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator

/** Элемент каталога. progress: -1 = не скачивается, 0..100 = идёт загрузка. */
data class AppItem(
    val name: String,
    val description: String,
    val version: String,
    val apkUrl: String
) {
    var progress: Int = -1
}

class AppAdapter(
    private val items: List<AppItem>,
    private val onInstall: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: TextView = view.findViewById(R.id.icon)
        val name: TextView = view.findViewById(R.id.name)
        val version: TextView = view.findViewById(R.id.version)
        val desc: TextView = view.findViewById(R.id.desc)
        val progress: LinearProgressIndicator = view.findViewById(R.id.progress)
        val btn: MaterialButton = view.findViewById(R.id.btn)
    }

    private val tileColors = intArrayOf(
        0xFF8B7CFF.toInt(), 0xFF4FC3F7.toInt(), 0xFFFF8A80.toInt(),
        0xFF69F0AE.toInt(), 0xFFFFD54F.toInt(), 0xFFFF80AB.toInt()
    )

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]

        holder.name.text = item.name
        holder.icon.text = item.name.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
        holder.icon.backgroundTintList = ColorStateList.valueOf(
            tileColors[(item.name.hashCode() and 0x7fffffff) % tileColors.size]
        )

        holder.version.text = if (item.version.isEmpty()) "" else "v${item.version}"
        holder.version.visibility = if (item.version.isEmpty()) View.GONE else View.VISIBLE

        holder.desc.text = item.description
        holder.desc.visibility = if (item.description.isEmpty()) View.GONE else View.VISIBLE

        if (item.progress >= 0) {
            holder.progress.visibility = View.VISIBLE
            holder.progress.setProgressCompat(item.progress, true)
            holder.btn.text = "${item.progress}%"
            holder.btn.isEnabled = false
        } else {
            holder.progress.visibility = View.GONE
            holder.btn.text = "Установить"
            holder.btn.isEnabled = true
        }

        holder.btn.setOnClickListener { onInstall(item) }
    }
}
