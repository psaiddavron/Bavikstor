package com.example.minimarket

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val all = mutableListOf<AppItem>()
    private val shown = mutableListOf<AppItem>()
    private lateinit var adapter: AppAdapter
    private lateinit var status: TextView
    private lateinit var search: EditText
    private val prefs by lazy { getSharedPreferences("market", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        search = findViewById(R.id.search)
        val recycler = findViewById<RecyclerView>(R.id.recycler)

        adapter = AppAdapter(shown) { item -> downloadAndInstall(item) }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        findViewById<View>(R.id.refreshBtn).setOnClickListener { loadCatalog() }
        findViewById<View>(R.id.settingsBtn).setOnClickListener { showServerDialog() }
        search.doAfterTextChanged { applyFilter() }

        if (prefs.getString("url", "").isNullOrEmpty()) showServerDialog() else loadCatalog()
    }

    /** Диалог для ввода адреса catalog.json. */
    private fun showServerDialog() {
        val input = EditText(this).apply {
            setText(prefs.getString("url", ""))
            hint = "http://192.168.1.10:8080/catalog.json"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Адрес каталога")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                prefs.edit().putString("url", input.text.toString().trim()).apply()
                loadCatalog()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    /** Загружает catalog.json с вашего сервера. */
    private fun loadCatalog() {
        val url = prefs.getString("url", "").orEmpty()
        if (url.isEmpty()) {
            status.text = "Укажите адрес каталога (значок сервера вверху)"
            return
        }
        status.text = "Загрузка каталога…"
        thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 10_000
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONArray(text)
                val parsed = (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    AppItem(
                        name = o.getString("name"),
                        description = o.optString("description"),
                        version = o.optString("version"),
                        // относительные ссылки считаем от адреса каталога
                        apkUrl = URL(URL(url), o.getString("apk")).toString()
                    )
                }
                ui.post {
                    all.clear()
                    all.addAll(parsed)
                    applyFilter()
                }
            } catch (e: Exception) {
                ui.post { status.text = "Не удалось загрузить: ${e.message}" }
            }
        }
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(all.filter {
            q.isEmpty() || it.name.lowercase().contains(q) || it.description.lowercase().contains(q)
        })
        adapter.notifyDataSetChanged()
        status.text = when {
            all.isEmpty() -> "Каталог пуст"
            shown.isEmpty() -> "Ничего не найдено"
            else -> "Приложений: ${shown.size}"
        }
    }

    private fun setProgress(item: AppItem, value: Int) {
        item.progress = value
        val idx = shown.indexOfFirst { it === item }
        if (idx >= 0) adapter.notifyItemChanged(idx)
    }

    /** Скачивает APK во внутренний кэш и открывает системный установщик. */
    private fun downloadAndInstall(item: AppItem) {
        if (item.progress >= 0) return
        if (!canInstall()) return

        setProgress(item, 0)
        thread {
            try {
                val dir = File(cacheDir, "apk").apply { mkdirs() }
                val file = File(dir, "${item.apkUrl.hashCode()}.apk")
                val conn = URL(item.apkUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                val total = conn.contentLength
                var done = 0L
                var last = -1

                conn.inputStream.use { input ->
                    file.outputStream().use { output ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != last) {
                                    last = pct
                                    ui.post { setProgress(item, pct) }
                                }
                            }
                        }
                    }
                }

                ui.post {
                    setProgress(item, -1)
                    openInstaller(file)
                }
            } catch (e: Exception) {
                ui.post {
                    setProgress(item, -1)
                    Toast.makeText(this, "Ошибка скачивания: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** На Android 8+ нужно разрешение «Установка из неизвестных источников» для этого приложения. */
    private fun canInstall(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Разрешите установку из этого приложения и нажмите ещё раз", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return false
        }
        return true
    }

    private fun openInstaller(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }
}
